use std::io;

fn main() {
    let mut input1 = String::new();
    let mut input2 = String::new();
    let mut input3 = String::new();
    let mut input4 = String::new();

    println!("\nPlease enter book code");
    io::stdin().read_line(&mut input1).expect("Not a valid string");
    let R:f32 = input1.trim().parse().expect("Not a valid number");

    println!("Please enter book code");
    io::stdin().read_line(&mut input2).expect("Not a valid string");
    let A:f32 = input2.trim().parse().expect("Not a valid number");

    println!("Please enter book code");
    io::stdin().read_line(&mut input2).expect("Not a valid string");
    let D:f32 = input3.trim().parse().expect("Not a valid number");

    println!("Please enter book code");
    io::stdin().read_line(&mut input4).expect("Not a valid string");
    let N:f32 = input4.trim().parse().expect("Not a valid number");


    //menu
    let book:R = "Rust for beginners";
    let book:A = "AI Basics";
    let book:D = "Data Structures in Rust";
    let book:N = "Networking Essentials";

     let _code = R{
        println!("price = 15.000");
    }
     let _code = A{
        println!("price = 12.500");
    }
     let _code = D{
        println!("price = 20.000");
    }
     let _code = N{
        println!("price = 18.000");

    if cus
    }

}





    
    

    
    
    
    



    
